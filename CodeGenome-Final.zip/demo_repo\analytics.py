"""Analytics tracking."""


def track_event(event_name: str, data: dict) -> None:
    pass


def get_dashboard_metrics() -> dict:
    return {}
