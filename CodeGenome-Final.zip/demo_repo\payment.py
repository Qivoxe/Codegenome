"""Payment processing utilities."""


def process_payment(amount: float, method: str) -> dict:
    return {"status": "success", "amount": amount, "method": method}


def refund(transaction_id: str, amount: float) -> bool:
    return True
