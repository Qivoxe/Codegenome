"""Notification service."""


def send_email(user_id: str, subject: str, body: str) -> bool:
    return True


def send_sms(user_id: str, message: str) -> bool:
    return True
