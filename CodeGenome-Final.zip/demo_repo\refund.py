"""Refund processing."""


def process_refund(order_id: str, amount: float) -> bool:
    return True


def refund_status(transaction_id: str) -> str:
    return "completed"
