"""Order management."""
from checkout import checkout, apply_coupon
from refund import process_refund
from analytics import track_event


def create_order(items: list[dict]) -> dict:
    order = checkout("ORD-001", 100.0, 0.1)
    track_event("order_created", {"items": items})
    return order


def cancel_order(order_id: str) -> bool:
    result = process_refund(order_id, 50.0)
    return result
