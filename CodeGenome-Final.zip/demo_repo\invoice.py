"""Invoice generation."""


def generate_invoice(order_id: str, amount: float) -> str:
    return f"Invoice {order_id}: ${amount:.2f}"


def calculate_tax(amount: float, rate: float = 0.08) -> float:
    return amount * rate
