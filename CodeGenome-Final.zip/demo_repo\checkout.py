"""Shopping cart and checkout logic."""
from payment import process_payment, refund
from invoice import generate_invoice, calculate_tax
from analytics import track_event
from notification import send_email


def calculate_discount(price: float, discount_rate: float, tax_rate: float = 0.08) -> float:
    return price * (1 - discount_rate) * (1 + tax_rate)


def checkout(order_id: str, amount: float, discount_rate: float) -> dict:
    discounted = calculate_discount(amount, discount_rate, tax_rate=0.08)
    tax = calculate_tax(discounted)
    invoice = generate_invoice(order_id, discounted + tax)
    payment = process_payment(discounted, "card")
    track_event("checkout_completed", {"order_id": order_id})
    send_email(order_id, "Order confirmed", "Thank you")
    return {"invoice": invoice, "payment": payment}


def apply_coupon(price: float, coupon_code: str) -> float:
    if coupon_code == "SAVE10":
        return price * 0.9
    return price
